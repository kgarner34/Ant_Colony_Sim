import java.util.*;

public class Ant 
{
	final int QLoc = 13;
	private int lifeSpan;
	private int spawnTurn;
	private int ID;
	boolean isAlive;
	private int locationX;
	private int locationY;
	public static Random randomGen = new Random();
	public int randomNum;
	
	public Ant()
	{
		lifeSpan = 3650;
		isAlive = true;
		locationX = QLoc;
		locationY = QLoc;
		spawnTurn = 0;
	}
		
	public void setLifeSpan(int span)
	{
		lifeSpan = span;
	}
	
	public void setAlive(boolean alive)
	{
		isAlive = alive;
	}
	
	public void setX(int x)
	{
		locationX = x;
	}
	
	public void setY(int y)
	{
		locationY = y;
	}
	
	public void setID(int ID)
	{
		ID = ID;
	}
	
	public void setSpawnTurn(int turn)
	{
		spawnTurn = turn;
	}
	
		public int getLifeSpan()
		{
			return lifeSpan;
		}
		
		public boolean getAlive()
		{
			return isAlive;
		}
		
		public int getX()
		{
			return locationX;
		}
		
		public int getY()
		{
			return locationY;
		}
		
		public int getID()
		{
			return ID;
		}
		
		public int getSpawnTurn()
		{
			return spawnTurn;
		}
		
		public void checkLifeSpan(int turn, Node[][] nodeArray)
		{
			if (lifeSpan <= (turn-spawnTurn))
			{
				this.die(nodeArray);
			}
		}
		

		public void die(Node[][] nodeArray)
		{
			this.setAlive(false);
		}
		

		public void takeTurn(Node[][] nodeArray, LinkedList<Ant> antList, int turn, LinkedList<Bala> balaList)
		{
			
		}
	
}