import java.util.LinkedList;


public class Bala extends Ant 
{
	public Bala()
	{
		this.setX(0);
		this.setY(0);
	}

	public void move(Node[][] nodeArray)
	{
		int randomX = this.getX();
		int randomY = this.getY();
		int currentX = this.getX();
		int currentY = this.getY(); 
		while (randomX == this.getX() && randomY == this.getY())
		{
			randomNum = randomGen.nextInt(3);
			if (randomNum == 0 && this.getX() > 0)
				randomX = (this.getX()-1);
			else if (randomNum == 2 && this.getX() < 26)
				randomX = (this.getX()+1);
			else
			{} 
			randomNum = randomGen.nextInt(3);
			if (randomNum == 0 && this.getY() > 0)
				randomY = (this.getY()-1);
			else if (randomNum == 2 && this.getY() < 26)
				randomY = (this.getY()+1); 
			else
			{} 
		}
		nodeArray[currentX][currentY].setBalaCount(nodeArray[currentX][currentY].getBalaCount()-1);

		nodeArray[randomX][randomY].setBalaCount(nodeArray[randomX][randomY].getBalaCount()+1);
		this.setX(randomX);
		this.setY(randomY);
	}
	
	public boolean checkForEnemies(Node[][] nodeArray)
	{
		boolean enemyPresent = false;
		if (nodeArray[this.getX()][this.getY()].getQueenPresent() ||
			nodeArray[this.getX()][this.getY()].getForagerCount() > 0 ||
			nodeArray[this.getX()][this.getY()].getScoutCount() > 0 ||
			nodeArray[this.getX()][this.getY()].getSoldierCount() > 0)
		{
			enemyPresent = true;
		}
		return enemyPresent;
	}

	public void attack(Node[][] nodeArray, LinkedList<Ant> antList)
	{
		boolean antFound = false; 
		
		if (randomGen.nextInt(100) < 50)
		{
			for (int i = 0; i < antList.size(); i++)
			{
				if (!antFound)
				{
					if (antList.get(i).getX() == this.getX() && antList.get(i).getY() == this.getY())
					{
						antList.get(i).die(nodeArray);
					}
				}
			}
		}
		else
		{

		}
	}
	
	public void die(Node[][] nodeArray)
	{
		this.setAlive(false);
		nodeArray[this.getX()][this.getY()].setBalaCount(nodeArray[this.getX()][this.getY()].getBalaCount()-1);
	}
	
	public void takeTurn(Node[][] nodeArray, LinkedList<Ant> antList, int turn, LinkedList<Bala> balaList)
	{
		if (checkForEnemies(nodeArray))
		{
			attack(nodeArray, antList);
		}
		else 
		{
			move(nodeArray);
			if (checkForEnemies(nodeArray))
			{
				attack(nodeArray, antList);
			}
		}
		this.checkLifeSpan(turn, nodeArray);
	}
}