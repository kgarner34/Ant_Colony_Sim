
import java.awt.List;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.EventListener;
import java.util.*;
import javax.swing.JOptionPane;

public class AntSim implements SimulationEventListener, ActionListener
{
	javax.swing.Timer Timer;
	final int size = 27;
	final int QLocal = 13;
	final int normFood = 1000;
	private ColonyView colonyView = new ColonyView(size, size);
	private ColonyNodeView[][] colonyNodeView = new ColonyNodeView[size][size];
	private Node[][] colony = new Node[size][size];
	private int day = 0;
	private int turn = 0;
	private AntSimGUI antSim = new AntSimGUI();
	LinkedList<Ant> antList = new LinkedList<Ant>();
	LinkedList<Bala> balaList = new LinkedList<Bala>();
	public int balaID;
	public static Random randomGen = new Random();
	public int randomNum;
	
	public AntSim() 
	{
		antSim.initGUI(colonyView);
		antSim.addSimulationEventListener(this);
	}

	public void initColonyNodes()
	{	
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				colony[i][j] = new Node(i, j);
				colonyNodeView[i][j] = new ColonyNodeView();
				colonyNodeView[i][j].setID(i + ", " + j);
				colonyView.addColonyNodeView(colonyNodeView[i][j], i, j);
			}
		}
		colony[QLocal][QLocal].setFoodCount(normFood);
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				if (!(i > QLocal-2 && i < QLocal+2 && j > QLocal-2 && j < QLocal+2))
				{
					if (randomGen.nextInt(100) < 25)
					{
						colony[i][j].setFoodCount(randomGen.nextInt(501)+500);
					}
				}
				else
				{
					colony[i][j].setShown(true);
				}
			}
		}
		updateGUI();
	}
	
	public void InitAnts()
	{
		antList.add(new Queen());
		colony[QLocal][QLocal].setQueenPresent(true);
		for (int i = 0; i < 10; i++)
		{
			antList.add(new Soldier());
			((Soldier) antList.get(i+1)).setID(i+1);
			colony[QLocal][QLocal].setSoldierCount(colony[QLocal][QLocal].getSoldierCount()+1);
		}
		
		for (int i = 0; i < 50; i++)
		{
			antList.add(new Forager());
			((Forager) antList.get(i+11)).setID(i+11);
			colony[QLocal][QLocal].setForagerCount(colony[QLocal][QLocal].getForagerCount()+1);
		}
		
		for (int i = 0; i < 4; i++)
		{
			antList.add(new Scout());
			((Scout) antList.get(i+61)).setID(i+61);
			colony[QLocal][QLocal].setScoutCount(colony[QLocal][QLocal].getScoutCount()+1);
		}
		updateGUI();
	}

	public void updateGUI()
	{
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				if (colony[i][j].getShown())
					colonyNodeView[i][j].showNode();
				//sett here or to handle in this way) *NOTE*
				if (colony[i][j].getQueenPresent())
				{
					colonyNodeView[i][j].setQueen(true);
					colonyNodeView[i][j].showQueenIcon();
				}
				colonyNodeView[i][j].setForagerCount(colony[i][j].getForagerCount());
				colonyNodeView[i][j].setScoutCount(colony[i][j].getScoutCount());
				colonyNodeView[i][j].setSoldierCount(colony[i][j].getSoldierCount());
				colonyNodeView[i][j].setBalaCount(colony[i][j].getBalaCount());
				colonyNodeView[i][j].setFoodAmount(colony[i][j].getFoodCount());
				colonyNodeView[i][j].setPheromoneLevel(colony[i][j].getPheromoneCount());

				if (colony[i][j].getForagerCount() > 0)
					colonyNodeView[i][j].showForagerIcon();
				else
					colonyNodeView[i][j].hideForagerIcon();
				
				if (colony[i][j].getScoutCount() > 0)
					colonyNodeView[i][j].showScoutIcon();
				else
					colonyNodeView[i][j].hideScoutIcon();
				
				if (colony[i][j].getSoldierCount() > 0)
					colonyNodeView[i][j].showSoldierIcon();
				else
					colonyNodeView[i][j].hideSoldierIcon();
				
				if (colony[i][j].getBalaCount() > 0)
					colonyNodeView[i][j].showBalaIcon();
				else
					colonyNodeView[i][j].hideBalaIcon();
				day = turn/10;
				antSim.setTime("Day: " + day + ", Turn: " + turn%10);
			}
		}
	}

	public void singleTurn()
	{
		if (simNotOver())
		{
			if (randomGen.nextInt(100) < 3)
			{
				balaList.add(new Bala());
				balaList.get(balaList.size()-1).setID(balaID);
				balaList.get(balaList.size()-1).setSpawnTurn(turn);
				balaID++;
			}

			for (int i = 0; i < antList.size(); i++)
			{
				antList.get(i).takeTurn(colony, antList, turn, balaList);
			}
			Iterator<Bala> balaItr = balaList.iterator();
			while (balaItr.hasNext())
			{
				if (!(balaItr.next().getAlive()))
				{
					balaItr.remove();
				}
			}
			
			for (int i = 0; i < balaList.size(); i++)
			{
				balaList.get(i).takeTurn(colony, antList, turn, balaList);
			}
			Iterator<Ant> antItr = antList.iterator();
			while (antItr.hasNext())
			{
				if (!(antItr.next().getAlive()))
				{
					antItr.remove();
				}
			}
			
			if (turn%10 == 0)
			{
				for (int i = 0; i < size; i++)
				{
					for (int j = 0; j < size; j++)
					{
					   colony[i][j].setPheromoneCount(colony[i][j].getPheromoneCount()/2);
					}
				}
			}
			turn++;
			updateGUI();
		}
		else 
		{
			JOptionPane.showMessageDialog(null, "The Queen is dead simulation over.  Press enter to continue...");
			System.exit(0);
		}
	}

	public void simulationEventOccurred(SimulationEvent simEvent) 
	{ 
	    if (simEvent.getEventType() == SimulationEvent.NORMAL_SETUP_EVENT) 
	    { 
			initColonyNodes();
			InitAnts();
			updateGUI();
	    } 
	    else if (simEvent.getEventType() == SimulationEvent.QUEEN_TEST_EVENT) 
	    { 
	    	initColonyNodes();
	    	antList.add(new Queen());
			colony[QLocal][QLocal].setQueenPresent(true);
	    	for (int i = 0; i < 1000; i++)
	    	{
	    		antList.get(0).takeTurn(colony, antList, turn, balaList);
	    		turn++;
	    		updateGUI();
	    	}
	    	updateGUI();
	    } 
	    else if (simEvent.getEventType() == SimulationEvent.SCOUT_TEST_EVENT) 
	    { 
	    	initColonyNodes();
	    	antList.add(new Queen());
		colony[QLocal][QLocal].setQueenPresent(true);
	    	antList.add(new Scout());
	    	colony[QLocal][QLocal].setScoutCount(colony[QLocal][QLocal].getScoutCount()+1);
	    	updateGUI();
	    	for (int i = 0; i < 1000; i++)
	    	{
	    	 ((Scout) antList.get(1)).takeTurn(colony, antList, turn, balaList);
	    	 turn++;
	    	 updateGUI();
	    	}
	    } 
	    else if (simEvent.getEventType() == SimulationEvent.FORAGER_TEST_EVENT) 
	    { 
	        initColonyNodes();
	        antList.add(new Queen());
	        colony[QLocal][QLocal].setQueenPresent(true);
	        antList.add(new Forager());
	        colony[QLocal][QLocal].setForagerCount(colony[QLocal][QLocal].getForagerCount()+1);
	        for (int i = 10; i < 16; i++)
		{
			for (int j = 10; j < 16; j++)
			{
				colony[i][j].setShown(true);
				if(!(i > QLocal && i < QLocal && j > QLocal && j < QLocal))
				colony[i][j].setFoodCount(0);
			}
		}
		colony[10][14].setFoodCount(randomGen.nextInt(501)+500);
	        updateGUI();
	        for (int i = 0; i < 6000; i++) 
	        {
	            ((Forager) antList.get(1)).takeTurn(colony, antList, turn, balaList);
	            turn++;
	    	    updateGUI();
	    	}
	    } 
	    else if (simEvent.getEventType() == SimulationEvent.SOLDIER_TEST_EVENT)
	    { 
	    	if (antList.size() < 1 && balaList.size() < 1)
	    	{
	    		initColonyNodes();
	    		antList.add(new Queen());
	    		colony[QLocal][QLocal].setQueenPresent(true);
	    		antList.add(new Soldier());
		    	balaList.add(new Bala());
		    	colony[QLocal][QLocal].setSoldierCount(1);
		    	for (int i = 0; i < size; i++)
		        {
			    for (int j = 0; j < size; j++)
			    {
				colony[i][j].setShown(true);
			    }
		       }
		    	updateGUI();
	    	}
	    	for (int i = 0; i < 6000; i++)
	    	{
	    	    antList.get(1).takeTurn(colony, antList, turn, balaList);
	    	    balaList.get(0).takeTurn(colony, antList, turn, balaList);
	    	    turn++;
	    	    updateGUI();
	    	}
	    } 
	    else if (simEvent.getEventType() == SimulationEvent.RUN_EVENT) 
	    { 
	    	Timer = new javax.swing.Timer(1000, this);
	    	Timer.start();
	    } 
	    else if (simEvent.getEventType() == SimulationEvent.STEP_EVENT) 
	    { 
	    	singleTurn();
	    } 
	    else 
	    { 
	    	System.out.println("ERROR");
	    } 
	}
	
	public boolean simNotOver()
	{
		return antList.get(0).getAlive();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		if (!antList.get(0).getAlive())
		{
			Timer.stop();
		}
		else
		{
			singleTurn();
		}
	}
}