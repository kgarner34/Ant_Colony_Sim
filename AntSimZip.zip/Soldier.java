import java.util.*;

public class Soldier extends Ant
{
	public Soldier()
	{
		
	}
	
	public void move(Node[][] nodeArray, LinkedList<Bala> balaList)
	{	
		int randomX = this.getX();
		int randomY = this.getY(); 
		int currentX = this.getX();
		int currentY = this.getY();

		if (checkAdjSquares(nodeArray, balaList))
		{
			
		}
		else
		{
			while (randomX == this.getX() && randomY == this.getY())
			{
				randomNum = randomGen.nextInt(3);
				if (randomNum == 0 && this.getX() > 0)
					randomX = (this.getX()-1);
				else if (randomNum == 2 && this.getX() < 26)
					randomX = (this.getX()+1);
				else
				{}
				randomNum = randomGen.nextInt(3);
				if (randomNum == 0 && this.getY() > 0)
					randomY = (this.getY()-1);
				else if (randomNum == 2 && this.getY() < 26)
					randomY = (this.getY()+1);
				else
				{}
				if (!nodeArray[randomX][randomY].getShown())
				{
					randomX = currentX;
					randomY = currentY;
				}
			}
			nodeArray[currentX][currentY].setSoldierCount(nodeArray[currentX][currentY].getSoldierCount()-1);

			nodeArray[randomX][randomY].setSoldierCount(nodeArray[randomX][randomY].getSoldierCount()+1);
			this.setX(randomX);
			this.setY(randomY);
		}
	}

	public boolean checkAdjSquares(Node[][] nodeArray, LinkedList<Bala> balaList)
	{
		boolean enemyFound = false;
		for (int i = 0; i < balaList.size(); i++)
		{
			if (balaList.get(i).getX() >= this.getX()-1 && balaList.get(i).getX() <= this.getX()+1)
			{
				if (balaList.get(i).getY() >= this.getY()-1 && balaList.get(i).getY() <= this.getY()+1)
				{
					if (nodeArray[balaList.get(i).getX()][balaList.get(i).getY()].getShown())
					{
						enemyFound = true;
						nodeArray[this.getX()][this.getY()].setSoldierCount(nodeArray[this.getX()][this.getY()].getSoldierCount()-1);
						nodeArray[balaList.get(i).getX()][balaList.get(i).getY()].setSoldierCount(nodeArray[balaList.get(i).getX()][balaList.get(i).getY()].getSoldierCount()+1);
						this.setX(balaList.get(i).getX());
						this.setY(balaList.get(i).getY());
					}
				}
			}
		}
		return enemyFound;
	}
 
	public boolean checkForEnemies(Node[][] nodeArray)
	{
		boolean enemyPresent = false;
		if (nodeArray[this.getX()][this.getY()].getBalaCount() > 0)
		{
			enemyPresent = true;
		}
		return enemyPresent;
	}

	public void attack(Node[][] nodeArray, LinkedList<Bala> balaList)
	{
		boolean antFound = false;
		if (randomGen.nextInt(100) < 50)
		{
			for (int i = 0; i < balaList.size(); i++)
			{
				if (!antFound)
				{
					if (balaList.get(i).getX() == this.getX() && balaList.get(i).getY() == this.getY())
					{
						balaList.get(i).die(nodeArray);
					}
				}
			}	
		}
		else
		{

		}
	}

	public void die(Node[][] nodeArray)
	{
		this.setAlive(false);
		nodeArray[this.getX()][this.getY()].setSoldierCount(nodeArray[this.getX()][this.getY()].getSoldierCount()-1);
	}

	public void takeTurn(Node[][] nodeArray, LinkedList<Ant> antList, int turn, LinkedList<Bala> balaList)
	{
	        if (checkForEnemies(nodeArray))
		{
			attack(nodeArray, balaList);
		}
		else 
		{
			move(nodeArray, balaList);
			if (checkForEnemies(nodeArray))
			{
				attack(nodeArray, balaList);
			}
		}
		this.checkLifeSpan(turn, nodeArray);
	}
}