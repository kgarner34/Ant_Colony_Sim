import java.util.*;

public class Scout extends Ant
{
	public Scout()
	{
	
	}
	
	public void move(Node[][] nodeArray)
	{
		int randomX = this.getX();
		int randomY = this.getY();
		int currentX = this.getX();
		int currentY = this.getY();
		
		while (randomX == this.getX() && randomY == this.getY())
		{
			randomNum = randomGen.nextInt(3);
			if (randomNum == 0 && this.getX() > 0)
				randomX = (this.getX()-1);
			else if (randomNum == 2 && this.getX() < 26)
				randomX = (this.getX()+1);
			else
			{}
			randomNum = randomGen.nextInt(3);
			if (randomNum == 0 && this.getY() > 0)
				randomY = (this.getY()-1);
			else if (randomNum == 2 && this.getY() < 26)
				randomY = (this.getY()+1);
			else
			{}
		}
		nodeArray[currentX][currentY].setScoutCount(nodeArray[currentX][currentY].getScoutCount()-1);
		
		nodeArray[randomX][randomY].setScoutCount(nodeArray[randomX][randomY].getScoutCount()+1);
		if (!(nodeArray[randomX][randomY].getShown()))
		{
			nodeArray[randomX][randomY].setShown(true);
		}
		this.setX(randomX);
		this.setY(randomY);
	}
	
	public void die(Node[][] nodeArray)
	{
		this.setAlive(false);
		nodeArray[this.getX()][this.getY()].setScoutCount(nodeArray[this.getX()][this.getY()].getScoutCount()-1);
	}
	
	public void takeTurn(Node[][] nodeArray, LinkedList<Ant> antList, int turn, LinkedList<Bala> balaList)
	{
		move(nodeArray);
		this.checkLifeSpan(turn, nodeArray);
	}
}