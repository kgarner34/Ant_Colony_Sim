public class Node 
{
	//Attributes
	private boolean shown;
	private boolean queenPresent;
	private int foragerCount;
	private int scoutCount;
	private int soldierCount;
	private int balaCount;
	private int foodCount;
	private int pheromoneCount;
	private int XLoc;
	private int YLoc;

	public Node(int x, int y)
	{
		shown = false;
		queenPresent = false;
		foragerCount = 0;
		scoutCount = 0;
		soldierCount = 0;
		balaCount = 0;
		foodCount = 0;
		pheromoneCount = 0;
		XLoc = x;
		YLoc = y;
	}
	
	public void setShown(boolean show)
	{
		shown = show;
	}

	public void setQueenPresent (boolean present)
	{
		queenPresent = present;
	}

	public void setForagerCount(int count)
	{
		foragerCount = count;
	}

	public void setScoutCount(int count)
	{
		scoutCount = count;
	}

	public void setSoldierCount(int count)
	{
		soldierCount = count;
	}

	public void setBalaCount(int count)
	{
		balaCount = count;
	}

	public void setFoodCount(int count)
	{
		foodCount = count;
	}

	public void setPheromoneCount(int count)
	{
		pheromoneCount = count;
	}
		
	public void setXLoc(int x)
	{
		XLoc = x;
	}
	
	public void setYLoc(int y)
	{
		YLoc = y;
	}

	public boolean getShown()
	{
		return shown;
	}
	
	public boolean getQueenPresent()
	{
		return queenPresent;
	}

	public int getForagerCount()
	{
		return foragerCount;
	}

	public int getScoutCount()
	{
		return scoutCount;
	}

	public int getSoldierCount()
	{
		return soldierCount;
	}

	public int getBalaCount()
	{
		return balaCount;
	}

	public int getFoodCount()
	{
		return foodCount;
	}

	public int getPheromoneCount()
	{
		return pheromoneCount;
	}

	public int getXLoc()
	{
		return XLoc;
	}
	
	public int getYLoc()
	{
		return YLoc;
	}
}
