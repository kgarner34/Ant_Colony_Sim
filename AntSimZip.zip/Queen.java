import java.util.*;
import javax.swing.JOptionPane;

public class Queen extends Ant
{
	final int home = 13;
	final int ID = 0;
	final int QLife = 73000;
	public int assignedID;

	public Queen()
	{
		assignedID = 65;
		this.setID(ID);
		this.setLifeSpan(QLife);
	}
	
	public int getAssignedID()
	{
		return assignedID;
	}
	
	public void incAssgnID()
	{
		assignedID++;
	}
	
	public int consumeFood(int food, Node[][] nodeArray)
	{
		if (food > 0) 
		{
			food--;
			return food;
		}
		else
			this.die(nodeArray); 	
		return food;
	}

	public Ant hatchAnt(Node[][] nodeArray, int turn)
	{
		//50% chance forager, 25% scout and soldier
		randomNum = randomGen.nextInt(100)+1;
		if (randomNum < 50)
		{
			Forager forager = new Forager();
			nodeArray[home][home].setForagerCount(nodeArray[home][home].getForagerCount()+1);
			forager.setSpawnTurn(turn);
			forager.setID(assignedID);
			incAssgnID();  
			return forager;
		}
		else if (randomNum < 75)
		{
			Scout scout = new Scout();
			nodeArray[home][home].setScoutCount(nodeArray[home][home].getScoutCount()+1);
			scout.setSpawnTurn(turn);
			scout.setID(assignedID);
			incAssgnID();
			return scout;
		}
		else
		{
			Soldier soldier = new Soldier();
			nodeArray[home][home].setSoldierCount(nodeArray[home][home].getSoldierCount()+1);
			soldier.setSpawnTurn(turn);
			soldier.setID(assignedID);
			incAssgnID();
			return soldier;
		}
	}
	
	public void takeTurn(Node[][] nodeArray, LinkedList<Ant> antList, int turn, LinkedList<Bala> balaList)
	{
		if (turn%10 == 0)
		{
			antList.add(hatchAnt(nodeArray, turn));
		}

		int food = nodeArray[home][home].getFoodCount();
		nodeArray[home][home].setFoodCount(consumeFood(food, nodeArray));
		
		this.checkLifeSpan(turn, nodeArray);
		
		if (!(this.getAlive()))
		{
			JOptionPane.showMessageDialog(null, "The Queen is dead simulation over. Press enter to continue...");
			System.exit(0);
		}
	}
	
	public void die(Node[][] nodeArray)
	{
		this.setAlive(false);
		JOptionPane.showMessageDialog(null, "The Queen is dead simulation over. Press enter to continue...");
		System.exit(0);
	}
}