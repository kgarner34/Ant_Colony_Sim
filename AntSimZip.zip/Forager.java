import java.util.LinkedList;
import java.util.Stack;


public class Forager extends Ant
{
    private boolean carryingFood;
    private boolean stuckInLoop;
    private Stack<Node> movementHistory = new Stack<Node>();
    
    public Forager()
    {
        carryingFood = false;
        stuckInLoop = false;
    }
   
    public void setCarryingFood(boolean carrying)
    {
        carryingFood = carrying;
    }

    public void setStuckInLoop(boolean stuck)
    {
        stuckInLoop = stuck;
    }

    public boolean getCarryingFood()
    {
        return carryingFood;
    }

    public boolean getStuckInLoop()
    {
        return stuckInLoop;
    }

    public void move(Node[][] nodeArray)
    {
        if (!carryingFood)
        {
            boolean finished = false;
            LinkedList<Node> tempNodes = new LinkedList<Node>(); 
            if (movementHistory.size() > 9)
            {
                int count = 0;
                Stack<Node> copiedStack = (Stack<Node>) movementHistory.clone();
                Node tempNode = copiedStack.pop();
                while (!copiedStack.empty())
                {
                    if (tempNode.getXLoc() == copiedStack.peek().getXLoc() && tempNode.getYLoc() == copiedStack.peek().getYLoc())
                    {
                        count++;
                    }
                    copiedStack.pop();
                }
                if (count > 3)
                {
                    this.setStuckInLoop(true);
                    count = 0;
                }
            }
            if (stuckInLoop)
            {
              while (!finished)
              {
               try
               {
                for (int i = this.getX()-1; i <= this.getX()+1; i++)
                {
                    for (int j = this.getY()-1; j <= this.getY()+1; j++)
                    {
                        if (i != movementHistory.peek().getXLoc() || j != movementHistory.peek().getYLoc())
                        {
                            if (i != QLoc || j != QLoc)
                            {
                                if (i != this.getX() || j != this.getY())
                                {
                                    if (nodeArray[i][j].getShown())
                                    {
                                        if (tempNodes.size() < 1)
                                        {
                                            tempNodes.add(nodeArray[i][j]);
                                        }
                                        else
                                        {
                                            if (nodeArray[i][j].getFoodCount() == tempNodes.get(0).getFoodCount())
                                            {
                                                tempNodes.add(nodeArray[i][j]);
                                            }
                                            else if (nodeArray[i][j].getFoodCount() > tempNodes.get(0).getFoodCount())
                                            {
                                                tempNodes.clear();
                                                tempNodes.add(nodeArray[i][j]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                finished = true;
              }
              catch (IndexOutOfBoundsException e)
              {
                continue;
              }
           }
           randomNum = randomGen.nextInt(tempNodes.size());
           nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()-1);
           this.setX(tempNodes.get(randomNum).getXLoc());
           this.setY(tempNodes.get(randomNum).getYLoc());
           nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()+1);
           movementHistory.add(tempNodes.get(randomNum));
           if (nodeArray[this.getX()][this.getY()].getFoodCount() > 0)
           {
            this.setCarryingFood(true);
            nodeArray[this.getX()][this.getY()].setFoodCount(nodeArray[this.getX()][this.getY()].getFoodCount()-1);
            this.setStuckInLoop(false);
           }
            }
            else
            {
                while (!finished)
                {
                    try
                    {
                        for (int i = this.getX()-1; i <= this.getX()+1; i++)
                        {
                            for (int j = this.getY()-1; j <= this.getY()+1; j++)
                            {
                                if (i != movementHistory.peek().getXLoc() || j != movementHistory.peek().getYLoc())
                                {
                                    if (i != QLoc || j != QLoc)
                                    {
                                        if (i != this.getX() || j != this.getY())
                                        {
                                            if (nodeArray[i][j].getShown())
                                            {
                                                if (tempNodes.size() < 1)
                                                {
                                                    tempNodes.add(nodeArray[i][j]);
                                                 }
                                                else
                                                {
                                                    if (nodeArray[i][j].getPheromoneCount() == tempNodes.get(0).getPheromoneCount())
                                                    {
                                                        tempNodes.add(nodeArray[i][j]);
                                                    }
                                                    else if (nodeArray[i][j].getPheromoneCount() > tempNodes.get(0).getPheromoneCount())
                                                    {
                                                        tempNodes.clear();
                                                        tempNodes.add(nodeArray[i][j]);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        finished = true;
                    }
                    catch (IndexOutOfBoundsException e)
                    {
                        continue;
                    }
                }
                randomNum = randomGen.nextInt(tempNodes.size());
                nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()-1);
                this.setX(tempNodes.get(randomNum).getXLoc());
                this.setY(tempNodes.get(randomNum).getYLoc());
                nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()+1);
                movementHistory.add(tempNodes.get(randomNum));

                if (nodeArray[this.getX()][this.getY()].getFoodCount() > 0)
                {
                    this.setCarryingFood(true);
                    nodeArray[this.getX()][this.getY()].setFoodCount(nodeArray[this.getX()][this.getY()].getFoodCount()-1);
                }
            }
            }
            else 
            {
                if (movementHistory.size() > 0)
                {
                    if (this.getX() >= QLoc-1 && this.getX() <= QLoc+1 &&
                        this.getY() >= QLoc-1 && this.getY() <= QLoc+1)
                    {
                        this.depositPheromones(nodeArray);
                        nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()-1);
                        this.setX(QLoc);
                        this.setY(QLoc);
                        nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()+1);
                        nodeArray[this.getX()][this.getY()].setFoodCount(nodeArray[this.getX()][this.getY()].getFoodCount()+1);
                        this.setCarryingFood(false);
                        this.setStuckInLoop(false);
                        movementHistory.clear();
                        movementHistory.add(nodeArray[this.getX()][this.getY()]);
                    }
                    else
                    {
                        Node tempNode = movementHistory.pop();
                        this.depositPheromones(nodeArray);
                        nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()-1);
                        this.setX(tempNode.getXLoc());
                        this.setY(tempNode.getYLoc());
                        nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()+1);
                    }
                }
            }
    }
    
    public void depositPheromones(Node[][] nodeArray)
    {
        if (nodeArray[this.getX()][this.getY()].getPheromoneCount() < 1000)
        {
            nodeArray[this.getX()][this.getY()].setPheromoneCount(nodeArray[this.getX()][this.getY()].getPheromoneCount()+10);
        }
    }
    
    public void takeTurn(Node[][] nodeArray, LinkedList<Ant> antList, int turn, LinkedList<Bala> balaList)
    {
        if (this.getSpawnTurn() - turn == 0)
        {
            movementHistory.add(nodeArray[QLoc][QLoc]);
        }
        move(nodeArray);
        this.checkLifeSpan(turn, nodeArray);
    }
    
    public void die(Node[][] nodeArray)
    {
        this.setAlive(false);
        nodeArray[this.getX()][this.getY()].setForagerCount(nodeArray[this.getX()][this.getY()].getForagerCount()-1);
        if (this.getCarryingFood())
        {
            nodeArray[this.getX()][this.getY()].setFoodCount(nodeArray[this.getX()][this.getY()].getFoodCount()+1);
        }
    }
}